package com.we.conn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Conn {
	private static String driverName = "com.mysql.jdbc.Driver";
	private static String username = "root";
	private static String password = "123456";
	private static String url = "jdbc:mysql://localhost/fingertip";
	
	
	public Connection getConnection(){
		Connection con = null;
		try {
			Class.forName(driverName);
			try {
				con = DriverManager.getConnection(url, username, password);
				System.out.println("�ѻ�����ݿ������");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	     return con;
	}
	
}
