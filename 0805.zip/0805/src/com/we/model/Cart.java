package com.we.model;

public class Cart {
	private int cart;
	private int foodid;
	private int number;
	private String userid;
	private String description;
	private String foodmoney;
	private String shopid;
	private String datetime;
	private String userorderid;
	
	public String getUserorderid() {
		return userorderid;
	}
	public void setUserorderid(String userorderid) {
		this.userorderid = userorderid;
	}
	public String getDatetime() {
		return datetime;
	}
	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}
	public int getCart() {
		return cart;
	}
	public void setCart(int cart) {
		this.cart = cart;
	}
	public int getFoodid() {
		return foodid;
	}
	public void setFoodid(int foodid) {
		this.foodid = foodid;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getFoodmoney() {
		return foodmoney;
	}
	public void setFoodmoney(String foodmoney) {
		this.foodmoney = foodmoney;
	}
	public void setShopid(String shopid) {
		this.shopid = shopid;
	}
	public String getShopid() {
		return shopid;
	}
}
