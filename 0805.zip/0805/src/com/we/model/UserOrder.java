package com.we.model;

public class UserOrder {
	private int userorderid;
	private int foodid;
	private int number;
	private String userorderdate;
	private String userid;
	private String foodmoney;
	private String shopid;
	private String foodname;
	private Byte flag;
	public Byte getFlag() {
		return flag;
	}
	public void setFlag(Byte flag) {
		this.flag = flag;
	}
	public int getUserorderid() {
		return userorderid;
	}
	public void setUserorderid(int userorderid) {
		this.userorderid = userorderid;
	}
	public int getFoodid() {
		return foodid;
	}
	public void setFoodid(int foodid) {
		this.foodid = foodid;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getUserorderdate() {
		return userorderdate;
	}
	public void setUserorderdate(String userorderdate) {
		this.userorderdate = userorderdate;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getFoodmoney() {
		return foodmoney;
	}
	public void setFoodmoney(String foodmoney) {
		this.foodmoney = foodmoney;
	}
	public String getShopid() {
		return shopid;
	}
	public void setShopid(String shopid) {
		this.shopid = shopid;
	}
	public String getFoodname() {
		return foodname;
	}
	public void setFoodname(String foodname) {
		this.foodname = foodname;
	}
}
