package com.we.model;

public class Shoporder {
	private int shoporderid;
	private int foodid;
	private String shoporderdate;
	private int number;
	private String userid;
	private int shopid;
	public Byte getFlag() {
		return flag;
	}
	public void setFlag(Byte flag) {
		this.flag = flag;
	}
	private String foodmoney;
	private String foodname;
	private Byte flag;
	public String getFoodname() {
		return foodname;
	}
	public void setFoodname(String foodname) {
		this.foodname = foodname;
	}
	public String getFoodmoney() {
		return foodmoney;
	}
	public void setFoodmoney(String foodmoney) {
		this.foodmoney = foodmoney;
	}
	public int getShopid() {
		return shopid;
	}
	public void setShopid(int shopid) {
		this.shopid = shopid;
	}
	public int getShoporderid() {
		return shoporderid;
	}
	public void setShoporderid(int shoporderid) {
		this.shoporderid = shoporderid;
	}
	public int getFoodid() {
		return foodid;
	}
	public void setFoodid(int foodid) {
		this.foodid = foodid;
	}
	public String getShoporderdate() {
		return shoporderdate;
	}
	public void setShoporderdate(String shoporderdate) {
		this.shoporderdate = shoporderdate;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
}
