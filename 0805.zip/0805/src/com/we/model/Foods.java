package com.we.model;

public class Foods {
	private int foodid;
	private String foodname;
	private String description;
	private int shopid;
	private String foodmoney;
	public int getFoodid() {
		return foodid;
	}
	public void setFoodid(int foodid) {
		this.foodid = foodid;
	}
	public String getFoodname() {
		return foodname;
	}
	public void setFoodname(String foodname) {
		this.foodname = foodname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getShopid() {
		return shopid;
	}
	public void setShopid(int shopid) {
		this.shopid = shopid;
	}
	public String getFoodmoney() {
		return foodmoney;
	}
	public void setFoodmoney(String foodmoney) {
		this.foodmoney = foodmoney;
	}
	
}
