package com.we.ser;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.we.model.Foods;
import com.we.model.Shop;
import com.we.model.User;
import com.we.service.queryFoods;
import com.we.service.volidate;

public class LoginShopServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public LoginShopServlet() {
        super();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userid = request.getParameter("userid");
		String password = request.getParameter("password");
		System.out.println(userid);
		Shop shop = new Shop();
		shop.setShopid(Integer.valueOf(userid));
		shop.setPassword(password);		
		if(volidate.ShopLoginIsRight(shop)){
			HttpSession session = request.getSession();
			session.setAttribute("shop", shop);
			List<Foods> list = queryFoods.queryFoodsByShopid(shop.getShopid());
			session.setAttribute("foodlist", list);
			response.sendRedirect("../business.jsp");
		}
		else{
			response.sendRedirect("../shoplogin.jsp");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
