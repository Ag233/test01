package com.we.ser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.omg.PortableInterceptor.USER_EXCEPTION;

import com.we.model.Cart;
import com.we.model.User;
import com.we.model.UserOrder;
import com.we.service.DealUserOrder;
import com.we.service.queryCart;

public class UserOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public UserOrderServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("user");
		if(user==null){
			response.sendRedirect("../login.jsp");
		}
		else{
			List<UserOrder> listuserorder = new ArrayList<>();
			listuserorder = DealUserOrder.queryUserorderByUserid(user.getUserid());
			session.setAttribute("listuserorder", listuserorder);
			response.sendRedirect("../userorder.jsp");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
