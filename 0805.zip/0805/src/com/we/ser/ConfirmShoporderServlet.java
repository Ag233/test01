package com.we.ser;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.we.model.Cart;
import com.we.model.Shop;
import com.we.model.Shoporder;
import com.we.model.User;
import com.we.service.DealShopOrder;
import com.we.service.DealUserOrder;
import com.we.service.queryCart;


public class ConfirmShoporderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public ConfirmShoporderServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String s =request.getParameter("value");
		int[] a = new int[s.length()];
		for(int i=0;i<s.length();i++){
			a[i] = Integer.valueOf(String.valueOf(s.charAt(i)));
			System.out.println("aaa:"+a[i]);
		}
		HttpSession session = request.getSession();
		Shop shop = (Shop)session.getAttribute("shop");
		List<Shoporder> ubshoporderlist = (List<Shoporder>) session.getAttribute("ubshoporderlist");
		for(int i=0;i<a.length;i++){
			Shoporder shoporder = new Shoporder();
			shoporder = ubshoporderlist.get(a[i]);
			DealShopOrder.UpdateFlagByShoporderid(shoporder.getShoporderid());
		}
		ubshoporderlist = DealShopOrder.queryShoporderByShopid(shop.getShopid(), 0);
		session.setAttribute("ubshoporderlist",ubshoporderlist);
		response.sendRedirect("../businessunorder.jsp");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
