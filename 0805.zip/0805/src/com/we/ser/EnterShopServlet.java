package com.we.ser;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.we.model.Foods;
import com.we.model.User;
import com.we.service.queryCart;
import com.we.service.queryFoods;

public class EnterShopServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public EnterShopServlet() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		User user = new User();
		user = (User) session.getAttribute("user");
		if(session.getAttribute("user")!=null){
			 int totalcount = queryCart.queryTotalNumberByUserid(user.getUserid());
			 session.setAttribute("totalcount", totalcount);
		}
		if(request.getParameter("id")!=null){
			session.setAttribute("id", request.getParameter("id"));
		}
		for(int i=1;i<=8;i++){
			if(session.getAttribute("id").equals(String.valueOf(i))){
				session.setAttribute("id", String.valueOf(i));
				String userid = request.getParameter("userid");
				session.setAttribute("userid", userid);
				List<Foods> list = queryFoods.queryFoodsByShopid(i);
				session.setAttribute("listfoods", list);
				response.sendRedirect("../shopping.jsp");
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
