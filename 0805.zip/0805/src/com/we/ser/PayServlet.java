package com.we.ser;

import java.io.IOException;
import java.util.List;

import javax.crypto.SecretKeyFactorySpi;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.we.model.Cart;
import com.we.model.User;
import com.we.service.DealShopOrder;
import com.we.service.DealUserOrder;
import com.we.service.queryCart;


public class PayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public PayServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String s =request.getParameter("value");
		int[] a = new int[s.length()];
		for(int i=0;i<s.length();i++){
			a[i] = Integer.valueOf(String.valueOf(s.charAt(i)));
		}
		HttpSession session = request.getSession();
		User user = new User();
		user = (User)session.getAttribute("user");
		List<Cart> listcart = (List<Cart>) session.getAttribute("listcart");
		String time = DealUserOrder.getTime();
		System.out.println(time);
		for(int i=0;i<a.length;i++){
			Cart cart = new Cart();
			cart = listcart.get(a[i]);
			cart.setDatetime(time);
			DealUserOrder.InsertUserorderByCart(cart);
			DealShopOrder.InsertShoporderByCart(cart);
		}
		for(int i=0;i<a.length;i++){
			Cart cart = new Cart();
			cart = listcart.get(a[i]);
			if(queryCart.DeleteCartBycart(cart.getCart())!=false){
			}
			
		}
		System.out.println(user.getUserid()+"::::aaaaa");
		listcart = queryCart.queryCartByUserid(user.getUserid());
		session.setAttribute("listcart",listcart);
		response.sendRedirect("../cart1.jsp");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
