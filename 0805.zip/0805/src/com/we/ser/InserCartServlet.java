package com.we.ser;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.we.model.Foods;
import com.we.model.User;
import com.we.service.queryCart;

public class InserCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public InserCartServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String p = request.getParameter("pid");
		int i = Integer.valueOf(p);
		System.out.println(i+"sadasdasd");
		HttpSession session =  request.getSession();
		Foods food = new Foods();
		User user = new User();
		user = (User) session.getAttribute("user");
		List listfoods = (List)session.getAttribute("listfoods");
		food = (Foods) listfoods.get(i);
		int foodid = food.getFoodid();
		String userid = user.getUserid();
		if(queryCart.queryCartByFoodid(foodid, userid)!=-1){
			queryCart.UpdateNumberByCart(queryCart.queryCartByFoodid(foodid, userid));
			response.sendRedirect("EnterShopServlet");
		}
		else{
			queryCart.InsertCart(foodid, 1, userid);
			response.sendRedirect("EnterShopServlet");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
