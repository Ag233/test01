package com.we.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.we.conn.Conn;
import com.we.model.Cart;
import com.we.model.Foods;

public class queryCart {
	private static String sql = "select * from cart where userid=?";
	//���ݿ����
	private static PreparedStatement ps;
	
	public static List<Cart> queryCartByUserid(String userid){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, userid);
			ResultSet result = ps.executeQuery();
			List<Cart> list = new ArrayList<>();
			while(result.next()){
				System.out.print("cart:"+result.getInt("cart")
				+" foodid:"+result.getInt("foodid")
				+" number:"+result.getInt("number")
				+" userid:"+result.getString("userid"));
				System.out.println();
				Cart cart = new Cart();
				String description = queryFoods.queryDescriptionByFoodid(result.getInt("foodid"));
				String foodmoney = queryFoods.queryFoodmoneyByFoodid(result.getInt("foodid"));
				String shopid = queryFoods.queryShopidByFoodid(result.getInt("foodid"));
				System.out.println("shopid:"+shopid);
				cart.setDescription(description);
				cart.setShopid(shopid);
				cart.setFoodmoney(foodmoney);
				cart.setCart(result.getInt("cart"));
				cart.setFoodid(result.getInt("foodid"));
				cart.setNumber(result.getInt("number"));
				cart.setUserid(result.getString("userid"));
				list.add(cart);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return null;
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	public static boolean DeleteCartBycart(int cart){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		String s = null;
		try {
			ps = conn.prepareStatement("DELETE FROM cart where cart=?");
			ps.setInt(1, cart);
			if(ps.executeUpdate()!=-1){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}	
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return false;
	}
	
	public static int queryCartByFoodid(int foodid,String userid){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		String s = null;
		try {
			ps = conn.prepareStatement("select * from cart where foodid=?");
			ps.setInt(1, foodid);
			ResultSet result = ps.executeQuery();
			while(result.next()){
				if(userid.equals(result.getString("userid"))){
					return result.getInt("cart");
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}	
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return -1;
	}
	
	public static boolean UpdateNumberByCart(int cart){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		String s = null;
		try {
			ps = conn.prepareStatement("UPDATE cart SET number=number+1 where cart=?");
			ps.setInt(1, cart);
			if(ps.executeUpdate()!=-1){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}	
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return false;
	}
	
	public static boolean InsertCart(int foodid,int number,String userid){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		try {
			ps = conn.prepareStatement("insert into cart(foodid,number,userid)value (?,?,?)");
			ps.setInt(1, foodid);
			ps.setInt(2, number);
			ps.setString(3, userid);
			if(ps.executeUpdate()!=-1){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return false;
	}
	
	public static int queryTotalNumberByUserid(String userid){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		String s = null;
		int i = -1;
		try {
			ps = conn.prepareStatement("select sum(number) from cart where userid=?");
			ps.setString(1, userid);
			ResultSet result = ps.executeQuery();
			while(result.next()){
				i = result.getInt("sum(number)");
			}
			return i;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}	
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return i;
	}
}
