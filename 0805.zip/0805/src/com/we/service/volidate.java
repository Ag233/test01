package com.we.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.sql.Connection;
import com.we.conn.Conn;
import com.we.model.Shop;
import com.we.model.User;

public class volidate {
	private static String sql = "select * from user";
	//���ݿ����
	private static Statement stmt;
	public static boolean LoginIsRight(User user){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		try {
			stmt = conn.createStatement();
			ResultSet result = stmt.executeQuery(sql);
			while(result.next()){
				System.out.print("userid:"+result.getString("userid")
				+" password:"+result.getString("password"));
				if(user.getUserid().equals(result.getString("userid"))&&user.getPassword().equals(result.getString("password"))){
					return true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return false;
	}
	
	public static boolean ShopLoginIsRight(Shop shop){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		try {
			stmt = conn.createStatement();
			ResultSet result = stmt.executeQuery("select * from shop");
			while(result.next()){
				System.out.print("shopid:"+result.getInt("shopid")
				+" password:"+result.getString("password"));
				if(shop.getShopid()==result.getInt("shopid")&&shop.getPassword().equals(result.getString("password"))){
					return true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return false;
	}
}
