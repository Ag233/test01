package com.we.service;

import java.util.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.we.conn.Conn;
import com.we.model.Foods;
import java.sql.*;
public class queryFoods {
	private static String sql = "select * from foods where shopid=?";
	//���ݿ����
	private static PreparedStatement ps;
	public static List<Foods> queryFoodsByShopid(int shopid){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, shopid);
			ResultSet result = ps.executeQuery();
			List<Foods> list = new ArrayList<>();
			while(result.next()){
				System.out.print("foodid:"+result.getInt("foodid")
				+" foodname:"+result.getString("foodname")
				+" description:"+result.getString("description")
				+" shopid:"+result.getInt("shopid")
				+" foodmoney:"+result.getString("foodmoney"));
				System.out.println();
				Foods food = new Foods();
				food.setFoodid(result.getInt("foodid"));
				food.setFoodname(result.getString("foodname"));
				food.setDescription(result.getString("description"));
				food.setShopid(result.getInt("shopid"));
				food.setFoodmoney(result.getString("foodmoney"));
				list.add(food);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return null;
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}


	public static String queryDescriptionByFoodid(int foodid){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		String s = null;
		try {
			ps = conn.prepareStatement("SELECT description FROM foods where foodid=?");
			ps.setInt(1, foodid);
			ResultSet result = ps.executeQuery();
			while(result.next()){
				s = result.getString("description");
			}
			return s;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return s;
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	public static String queryFoodmoneyByFoodid(int foodid){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		String s = null;
		try {
			ps = conn.prepareStatement("SELECT foodmoney FROM foods where foodid=?");
			ps.setInt(1, foodid);
			ResultSet result = ps.executeQuery();
			while(result.next()){
				s = result.getString("foodmoney");
			}
			return s;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return s;
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	public static String queryShopidByFoodid(int foodid){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		String s = null;
		try {
			ps = conn.prepareStatement("SELECT shopid FROM foods where foodid=?");
			ps.setInt(1, foodid);
			ResultSet result = ps.executeQuery();
			while(result.next()){
				s = result.getString("shopid");
			}
			return s;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return s;
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	public static String queryFoodnameByFoodid(int foodid){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		String s = null;
		try {
			ps = conn.prepareStatement("SELECT foodname FROM foods where foodid=?");
			ps.setInt(1, foodid);
			ResultSet result = ps.executeQuery();
			while(result.next()){				
				s = result.getString("foodname");
			}
			return s;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return s;
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
}
