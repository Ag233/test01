package com.we.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.we.conn.Conn;
import com.we.model.Cart;
import com.we.model.Shoporder;
import com.we.model.UserOrder;

public class DealShopOrder {
	private static String sql = "select * from shoporder where shopid=? order by shoporderdate desc";
	//���ݿ����
	private static PreparedStatement ps;
	
	public static List<Shoporder> queryShoporderByShopid(int shopid,int i){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, shopid);
			ResultSet result = ps.executeQuery();
			List<Shoporder> list = new ArrayList<>();
			
			while(result.next()){
				if(result.getByte("flag")==i){
					System.out.print("shoporderid:"+result.getInt("shoporderid")
					+" foodid:"+result.getInt("foodid")
					+" number:"+result.getString("number")
					+" shoporderdate:"+result.getString("shoporderdate")
					+" userid:"+result.getString("userid"));
					System.out.println();
					Shoporder shoporder = new Shoporder();
//					String description = queryFoods.queryDescriptionByFoodid(result.getInt("foodid"));
					String foodmoney = queryFoods.queryFoodmoneyByFoodid(result.getInt("foodid"));
					String foodname = queryFoods.queryFoodnameByFoodid(result.getInt("foodid"));
					String date = result.getString("shoporderdate");
					date  = date.substring(0, 19);
					shoporder.setFlag(result.getByte("flag"));
					shoporder.setFoodname(foodname);
					shoporder.setFoodmoney(foodmoney);
					shoporder.setShopid(shopid);
					shoporder.setShoporderid(result.getInt("shoporderid"));
					shoporder.setFoodid(result.getInt("foodid"));
					shoporder.setNumber(result.getInt("number"));
					shoporder.setShoporderdate(date);
					shoporder.setUserid(result.getString("userid"));
					list.add(shoporder);
				}	
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	public static boolean UpdateFlagByShoporderid(int shoporderid){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		String s = null;
		try {
			ps = conn.prepareStatement("UPDATE shoporder SET flag=1 where shoporderid=?");
			ps.setInt(1, shoporderid);
			if(ps.executeUpdate()!=-1){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}	
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return false;
	}
	
	public static boolean InsertShoporderByCart(Cart cart){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		try {
			ps = conn.prepareStatement("insert into shoporder(foodid,shoporderdate,number,userid,flag,shopid)value (?,?,?,?,?,?)");
			ps.setInt(1, cart.getFoodid());
			ps.setString(2, cart.getDatetime());
			ps.setInt(3, cart.getNumber());
			ps.setString(4, cart.getUserid());
			ps.setByte(5, (byte) 0);
			ps.setString(6, cart.getShopid());
			if(ps.executeUpdate()!=-1){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return false;
	}
}
