package com.we.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.we.conn.Conn;
import com.we.model.Cart;
import com.we.model.UserOrder;

public class DealUserOrder {
	private static String sql = "select * from userorder where userid=? order by userorderdate desc";
	//���ݿ����
	private static PreparedStatement ps;
	
	public static List<UserOrder> queryUserorderByUserid(String userid){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, userid);
			ResultSet result = ps.executeQuery();
			List<UserOrder> list = new ArrayList<>();
			
			while(result.next()){
				System.out.print("foodid:"+result.getInt("foodid")
				+" number:"+result.getInt("number")
				+" userorderdate:"+result.getString("userorderdate")
				+" userid:"+result.getString("userid"));
				System.out.println();
				UserOrder userorder = new UserOrder();
//				String description = queryFoods.queryDescriptionByFoodid(result.getInt("foodid"));
				String foodmoney = queryFoods.queryFoodmoneyByFoodid(result.getInt("foodid"));
				String shopid = queryFoods.queryShopidByFoodid(result.getInt("foodid"));
				String foodname = queryFoods.queryFoodnameByFoodid(result.getInt("foodid"));
				String date = result.getString("userorderdate");
				date  = date.substring(0, 19);
				userorder.setFoodname(foodname);
				userorder.setFoodmoney(foodmoney);
				userorder.setShopid(shopid);
				userorder.setUserorderid(result.getInt("userorderid"));
				userorder.setFoodid(result.getInt("foodid"));
				userorder.setNumber(result.getInt("number"));
				userorder.setUserorderdate(date);
				userorder.setUserid(result.getString("userid"));
				list.add(userorder);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	public static Boolean InsertUserorderByCart(Cart cart){
		Conn con = new Conn();
		Connection conn = con.getConnection();
		try {
			ps = conn.prepareStatement("insert into userorder(foodid,number,userorderdate,userid)value (?,?,?,?)");
			ps.setInt(1, cart.getFoodid());
			ps.setInt(2, cart.getNumber());
			ps.setString(3, cart.getDatetime());
			ps.setString(4, cart.getUserid());
			if(ps.executeUpdate()!=-1){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		finally {
			try {
				conn.close();
				ps.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return false;
	}
	
	public static String getTime(){
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		java.util.Date time=null;
		try {
		   time= sdf.parse(sdf.format(new Date()));

		} catch (ParseException e) {

		   e.printStackTrace();
		   
		}
		
		return sdf.format(time);
	}
}
